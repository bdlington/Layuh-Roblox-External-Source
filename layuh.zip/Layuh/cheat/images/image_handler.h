#pragma once
#include "entry.h"
#include "cheat/menu/ui/render/drawing/image.h"

class CImageHandler {
public:
	void create_images();
};
inline CImageHandler image_handler;

